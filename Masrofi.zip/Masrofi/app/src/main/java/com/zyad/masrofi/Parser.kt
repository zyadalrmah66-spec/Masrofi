package com.zyad.masrofi

import android.content.Context
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

data class Tx(val id: String, val amount: Double, val credit: Boolean, val merchant: String,
              val category: String, val src: String, val time: Long)

object Cat {
    val all = listOf("أكل", "مواصلات", "فواتير", "تسوق", "ألعاب", "تحويلات", "أخرى", "دخل")
    private val k = mapOf(
        "أكل" to listOf("talabat", "طلبات", "mcdonald", "kfc", "مطعم", "cafe", "كافيه", "breadfast", "restaurant"),
        "مواصلات" to listOf("uber", "careem", "اوبر", "أوبر", "كريم", "بنزين", "petrol", "inDrive".lowercase()),
        "فواتير" to listOf("فاتورة", "bill", "vodafone", "فودافون", "orange", "اورنج", "etisalat", "اتصالات", "كهرباء", "غاز", "انترنت"),
        "تسوق" to listOf("amazon", "noon", "نون", "jumia", "جوميا", "carrefour", "كارفور", "mall", "مول", "سوق"),
        "ألعاب" to listOf("pubg", "steam", "google play", "playstation", "xbox", "ببجي"),
        "تحويلات" to listOf("instapay", "انستاباي", "تحويل", "transfer", "wallet", "محفظة")
    )
    fun guess(s: String) = k.entries.firstOrNull { e -> e.value.any { s.contains(it) } }?.key ?: "أخرى"
}

object Parser {
    private val amountRe = Regex(
        """(?:EGP|LE|ج\.?م|جنيه|مبلغ)\s*:?\s*([0-9][0-9,]*\.?[0-9]*)|([0-9][0-9,]*\.?[0-9]*)\s*(?:EGP|LE|جنيه|ج\.?م)""",
        RegexOption.IGNORE_CASE)
    private val merchRe = Regex("""(?:at|لدى|عند|to|إلى|الى)\s+([^\n.,0-9]{3,30})""", RegexOption.IGNORE_CASE)
    private val out = listOf("خصم", "سحب", "شراء", "دفع", "تم صرف", "purchase", "debited", "withdraw", "paid", "payment", "تحويل صادر", "sent")
    private val inn = listOf("إيداع", "ايداع", "استلام", "credited", "deposit", "received", "تحويل وارد", "استلمت")
    private val reject = listOf("otp", "رمز التحقق", "كود التفعيل", "verification code")

    private fun norm(s: String) = s.map { if (it in '٠'..'٩') '0' + (it - '٠') else it }.joinToString("")

    fun parse(src: String, raw: String, time: Long): Tx? {
        val b = norm(raw)
        val low = b.lowercase()
        if (reject.any { low.contains(it) }) return null
        val m = amountRe.find(b) ?: return null
        val amount = m.groupValues[1].ifEmpty { m.groupValues[2] }.replace(",", "").trimEnd('.').toDoubleOrNull() ?: return null
        val o = out.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
        val i = inn.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
        if (o == null && i == null) return null
        val credit = i != null && (o == null || i < o)
        val merchant = merchRe.find(b)?.groupValues?.get(1)?.trim() ?: src
        val cat = if (credit) "دخل" else Cat.guess(low + " " + merchant.lowercase())
        return Tx("$src|${time / 60000}|${b.hashCode()}", amount, credit, merchant, cat, src, time)
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("tx", Context.MODE_PRIVATE)

    fun load(c: Context): List<Tx> {
        val a = JSONArray(sp(c).getString("list", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Tx(o.getString("id"), o.getDouble("amount"), o.getBoolean("credit"), o.getString("merchant"),
                o.getString("cat"), o.getString("src"), o.getLong("time"))
        }.sortedByDescending { it.time }
    }

    private fun save(c: Context, l: List<Tx>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("credit", it.credit)
                .put("merchant", it.merchant).put("cat", it.category).put("src", it.src).put("time", it.time))
        }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    @Synchronized
    fun addAll(c: Context, items: List<Tx>): Int {
        val l = load(c).toMutableList()
        var n = 0
        for (t in items) {
            val dup = l.any { it.id == t.id || (it.amount == t.amount && it.credit == t.credit && abs(it.time - t.time) < 120000) }
            if (dup) continue
            val r = sp(c).getString("r_" + t.merchant, null)
            l.add(if (r != null) t.copy(category = r) else t)
            n++
        }
        if (n > 0) save(c, l)
        return n
    }

    @Synchronized
    fun setCategory(c: Context, id: String, cat: String) {
        val l = load(c)
        l.find { it.id == id }?.let { sp(c).edit().putString("r_" + it.merchant, cat).apply() }
        save(c, l.map { if (it.id == id) it.copy(category = cat) else it })
    }

    fun importInbox(c: Context): Int = try {
        val found = mutableListOf<Tx>()
        c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"),
            null, null, "date DESC")?.use { q ->
            var i = 0
            while (q.moveToNext() && i < 1000) {
                i++
                Parser.parse(q.getString(0) ?: "", q.getString(1) ?: "", q.getLong(2))?.let { found.add(it) }
            }
        }
        addAll(c, found)
    } catch (e: SecurityException) { 0 }
}
