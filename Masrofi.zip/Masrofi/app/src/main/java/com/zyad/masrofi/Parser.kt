package com.zyad.masrofi

import android.content.Context
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

data class Tx(val id: String, val amount: Double, val credit: Boolean, val merchant: String,
              val category: String, val src: String, val time: Long, val body: String = "",
              val type: String = "other", val card: String = "", val balance: Double = -1.0,
              val fee: Double = 0.0, val ref: String = "")

object Cat {
    val all = listOf("أكل", "مواصلات", "فواتير", "تسوق", "ألعاب", "تحويلات", "نقدي", "أخرى", "دخل")
    private val k = mapOf(
        "أكل" to listOf("talabat", "طلبات", "mcdonald", "kfc", "مطعم", "cafe", "كافيه", "breadfast", "restaurant", "elmenus"),
        "مواصلات" to listOf("uber", "careem", "اوبر", "أوبر", "كريم", "بنزين", "petrol", "indrive", "metro", "مترو"),
        "فواتير" to listOf("فاتورة", "bill", "vodafone", "فودافون", "orange", "اورنج", "etisalat", "اتصالات", "كهرباء", "غاز", "انترنت", "we.com.eg"),
        "تسوق" to listOf("amazon", "noon", "نون", "jumia", "جوميا", "carrefour", "كارفور", "mall", "مول", "سوق", "shein", "temu"),
        "ألعاب" to listOf("pubg", "steam", "google play", "playstation", "xbox", "ببجي", "midasbuy", "apple.com"),
        "تحويلات" to listOf("instapay", "انستاباي", "تحويل", "transfer", "wallet", "محفظة")
    )
    fun guess(s: String) = k.entries.firstOrNull { e -> e.value.any { s.contains(it) } }?.key ?: "أخرى"
}

object Parser {
    private const val CUR = "(?:EGP|LE|L\\.E|ج\\.?م|جنيه|جم)"
    private const val NUM = "([0-9][0-9,]*\\.?[0-9]*)"
    private val amountRe = Regex("(?:$CUR|مبلغ)\\s*:?\\s*$NUM|$NUM\\s*$CUR", RegexOption.IGNORE_CASE)
    private val balRe = Regex("(?:الرصيد(?:\\s+المتاح|\\s+الحالي)?|رصيد|balance|avail(?:able)?(?:\\s+bal(?:ance)?)?)\\s*:?\\s*(?:$CUR)?\\s*$NUM", RegexOption.IGNORE_CASE)
    private val feeRe = Regex("(?:رسوم|مصاريف|fees?)\\s*:?\\s*(?:$CUR)?\\s*$NUM", RegexOption.IGNORE_CASE)
    private val refRe = Regex("(?:رقم المرجع|المرجع|رقم العملية|ref(?:erence)?(?:\\s*(?:no|number|#))?|rrn|txn(?:\\s*id)?|transaction\\s*id)\\s*[:#]?\\s*([A-Za-z0-9]{5,20})", RegexOption.IGNORE_CASE)
    private val card1 = Regex("(?:تنتهي\\s*ب|تنتهى\\s*ب|ending(?:\\s*in|\\s*with)?|x{2,}|\\*{2,}|•{2,}|\\.{2,})\\s*([0-9]{4})", RegexOption.IGNORE_CASE)
    private val card2 = Regex("(?:card|بطاقة|كارت)[^0-9]{0,20}([0-9]{4})", RegexOption.IGNORE_CASE)
    private val site = Regex("([a-z0-9][a-z0-9-]*(?:\\.[a-z0-9-]+)*\\.(?:com|net|org|eg|io|co|me|store|shop|app))")
    private val phone = Regex("\\b(01[0125][0-9]{8})\\b")
    private val toRe = Regex("(?:إلى|الى|to|لحساب|للعميل)\\s+([^\\n,.:;]{2,40})", RegexOption.IGNORE_CASE)
    private val fromRe = Regex("(?:من|from)\\s+([^\\n,.:;]{2,40})", RegexOption.IGNORE_CASE)
    private val atRe = Regex("(?:at|لدى|عند|@|في)\\s+([^\\n,.:;]{2,40})", RegexOption.IGNORE_CASE)
    private val stop = Regex("\\s+(?:الرصيد|رصيد|balance|bal|avail|available|رقم|ref|on|بتاريخ|بطاقة|card|عبر|via|في يوم|using|بواسطة|مصاريف|رسوم|fees?)(?=\\s|$|[:.,]).*", RegexOption.IGNORE_CASE)
    private val bad = listOf("بطاقة", "card", "حساب", "account", "رصيد", "الرصيد", "كارت")
    private val noAmt = listOf("رصيد", "balance", "avail", "رسوم", "fee", "مصاريف")
    private val reject = listOf("otp", "رمز التحقق", "كود التفعيل", "verification code")
    private val out = listOf("خصم", "سحب", "شراء", "دفع", "تم صرف", "purchase", "debited", "withdraw", "paid", "payment", "تحويل صادر", "sent")
    private val inn = listOf("إيداع", "ايداع", "استلام", "credited", "deposit", "received", "تحويل وارد", "استلمت")
    private val atmK = arrayOf("atm", "سحب نقدي", "ماكينة", "صراف", "cash withdrawal")
    private val refundK = arrayOf("استرداد", "refund", "reversal", "مرتجع")
    private val depK = arrayOf("إيداع", "ايداع", "deposit", "credited", "تم إضافة", "اضافة مبلغ")
    private val topK = arrayOf("شحن رصيد", "recharge", "top up", "top-up")
    private val billK = arrayOf("فاتورة", "bill pay", "سداد")
    private val onlK = arrayOf("online", "اونلاين", "أونلاين", "e-commerce", "عبر الانترنت")
    private val posK = arrayOf("purchase", "شراء", "pos")
    private val prioIn = arrayOf("إلى حسابك", "الى حسابك", "to your account", "into your account")
    private val xOut = arrayOf("تحويل صادر", "تم تحويل", "تحويل إلى", "تحويل الى", "transferred to", "transfer to", "sent to", "إرسال", "ارسال")
    private val xIn = arrayOf("تحويل وارد", "استلمت", "تم استلام", "received from", "transfer from", "received")

    private fun norm(s: String) = s.map { if (it in '٠'..'٩') '0' + (it - '٠') else it }.joinToString("")
    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }
    private fun firstIdx(s: String, k: Array<String>) = k.map { s.indexOf(it) }.filter { it >= 0 }.minOrNull()
    private fun clean(s: String) = s.replace(stop, "").trim(' ', '-', ':', '*')

    private fun party(type: String, b: String, low: String, src: String): String {
        val web = site.find(low)?.groupValues?.get(1)
        val ph = phone.find(b)?.groupValues?.get(1)
        fun grab(r: Regex) = r.findAll(b).map { clean(it.groupValues[1]) }
            .firstOrNull { x -> x.length >= 2 && bad.none { x.lowercase().startsWith(it) } }
        return when (type) {
            "online" -> web ?: grab(atRe) ?: src
            "atm" -> grab(atRe) ?: "ATM"
            "out" -> grab(toRe) ?: ph ?: src
            "in", "dep", "ref" -> grab(fromRe) ?: ph ?: src
            "top" -> ph ?: src
            else -> web ?: grab(atRe) ?: grab(toRe) ?: ph ?: src
        }
    }

    fun parse(src: String, raw: String, time: Long): Tx? {
        val b = norm(raw)
        val low = b.lowercase()
        if (reject.any { low.contains(it) }) return null
        val m = amountRe.findAll(b).firstOrNull {
            val pre = low.substring(maxOf(0, it.range.first - 20), it.range.first)
            noAmt.none { k -> pre.contains(k) }
        } ?: return null
        val amount = m.groupValues[1].ifEmpty { m.groupValues[2] }.replace(",", "").trimEnd('.').toDoubleOrNull() ?: return null
        val domain = site.find(low)?.groupValues?.get(1)
        val xo = firstIdx(low, xOut); val xi = firstIdx(low, xIn)
        val type = when {
            has(low, *refundK) -> "ref"
            has(low, *atmK) -> "atm"
            has(low, *prioIn) -> "in"
            xo != null || xi != null -> if (xi != null && (xo == null || xi < xo)) "in" else "out"
            has(low, *depK) -> "dep"
            has(low, *topK) -> "top"
            has(low, *billK) -> "bill"
            domain != null || has(low, *onlK) -> "online"
            has(low, *posK) -> "pos"
            else -> "other"
        }
        val credit = when (type) {
            "ref", "in", "dep" -> true
            "other" -> {
                val o = out.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
                val i = inn.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
                if (o == null && i == null) return null
                i != null && (o == null || i < o)
            }
            else -> false
        }
        val who = party(type, b, low, src)
        val cat = when {
            credit -> "دخل"
            type == "atm" -> "نقدي"
            type == "out" -> "تحويلات"
            type == "bill" || type == "top" -> "فواتير"
            else -> Cat.guess(low + " " + who.lowercase())
        }
        val card = card1.find(b)?.groupValues?.get(1) ?: card2.find(b)?.groupValues?.get(1) ?: ""
        val bal = balRe.find(b)?.groupValues?.get(1)?.replace(",", "")?.trimEnd('.')?.toDoubleOrNull() ?: -1.0
        val fee = feeRe.find(b)?.groupValues?.get(1)?.replace(",", "")?.trimEnd('.')?.toDoubleOrNull() ?: 0.0
        val ref = refRe.find(b)?.groupValues?.get(1) ?: ""
        return Tx("$src|${time / 60000}|${b.hashCode()}", amount, credit, who, cat, src, time, raw, type, card, bal, fee, ref)
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("tx", Context.MODE_PRIVATE)

    fun load(c: Context): List<Tx> {
        val a = JSONArray(sp(c).getString("list", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Tx(o.getString("id"), o.getDouble("amount"), o.getBoolean("credit"), o.getString("merchant"),
                o.getString("cat"), o.getString("src"), o.getLong("time"), o.optString("body", ""),
                o.optString("type", "other"), o.optString("card", ""), o.optDouble("bal", -1.0),
                o.optDouble("fee", 0.0), o.optString("ref", ""))
        }.sortedByDescending { it.time }
    }

    private fun save(c: Context, l: List<Tx>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("amount", it.amount).put("credit", it.credit)
                .put("merchant", it.merchant).put("cat", it.category).put("src", it.src).put("time", it.time)
                .put("body", it.body).put("type", it.type).put("card", it.card).put("bal", it.balance)
                .put("fee", it.fee).put("ref", it.ref))
        }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    @Synchronized
    fun addAll(c: Context, items: List<Tx>): Int {
        val l = load(c).toMutableList()
        var n = 0
        for (t in items) {
            val dup = l.any { it.id == t.id || (it.amount == t.amount && it.credit == t.credit && abs(it.time - t.time) < 120000) }
            if (dup) continue
            val r = sp(c).getString("r_" + t.merchant, null)
            l.add(if (r != null) t.copy(category = r) else t)
            n++
        }
        if (n > 0) save(c, l)
        return n
    }

    @Synchronized
    fun setCategory(c: Context, id: String, cat: String) {
        val l = load(c)
        l.find { it.id == id }?.let { sp(c).edit().putString("r_" + it.merchant, cat).apply() }
        save(c, l.map { if (it.id == id) it.copy(category = cat) else it })
    }

    fun importInbox(c: Context): Int = try {
        val found = mutableListOf<Tx>()
        c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"),
            null, null, "date DESC")?.use { q ->
            var i = 0
            while (q.moveToNext() && i < 1000) {
                i++
                Parser.parse(q.getString(0) ?: "", q.getString(1) ?: "", q.getLong(2))?.let { found.add(it) }
            }
        }
        addAll(c, found)
    } catch (e: SecurityException) { 0 }
}
