package com.zyad.masrofi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (ms.isEmpty()) return
        val src = ms[0].originatingAddress ?: ""
        val body = ms.joinToString("") { it.messageBody ?: "" }
        Parser.parse(src, body, ms[0].timestampMillis)?.let { Store.addAll(c, listOf(it)) }
    }
}

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(s: StatusBarNotification) {
        if (s.packageName == packageName) return
        val e = s.notification.extras
        val body = listOfNotNull(
            e.getCharSequence("android.title"),
            e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text")
        ).joinToString(" ")
        Parser.parse(s.packageName, body, s.postTime)?.let { Store.addAll(this, listOf(it)) }
    }
}
