package com.zyad.masrofi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

val LocalInk = compositionLocalOf { Color.Black }
val LocalDark = compositionLocalOf { false }
val LocalLang = compositionLocalOf { "ar" }

private val D = mapOf(
    "home" to ("الرئيسية" to "Home"), "tx" to ("العمليات" to "Transactions"), "set" to ("الإعدادات" to "Settings"),
    "net" to ("الصافي" to "Net"), "inc" to ("دخل" to "Income"), "exp" to ("صرفت" to "Spent"),
    "month" to ("الشهر ده" to "This month"), "all" to ("الكل" to "All time"), "where" to ("صرفت فين" to "Where it went"),
    "empty" to ("مفيش عمليات لسه. من الإعدادات فعّل الصلاحيات واستورد الرسائل." to "No transactions yet. Enable permissions and import messages in Settings."),
    "msg" to ("نص الرسالة" to "Message"), "src" to ("المصدر" to "Source"), "when" to ("الوقت" to "When"), "cat" to ("التصنيف" to "Category"),
    "lang" to ("اللغة" to "Language"), "photo" to ("صورتك" to "Your photo"), "pick" to ("اختيار صورة" to "Choose photo"),
    "night" to ("الوضع الليلي" to "Night mode"), "setup" to ("التشغيل" to "Setup"),
    "p1" to ("السماح بقراءة الرسائل" to "Allow reading SMS"), "p2" to ("السماح بقراءة إشعارات البنوك" to "Allow bank notifications"),
    "p3" to ("استيراد الرسائل القديمة" to "Import old messages"), "added" to ("اتضاف" to "Added"), "egp" to ("جنيه" to "EGP"),
    "type" to ("نوع العملية" to "Type"), "card" to ("الكارت" to "Card"), "bal" to ("الرصيد بعد العملية" to "Balance after"),
    "fee" to ("الرسوم" to "Fee"), "ref" to ("رقم المرجع" to "Reference"),
    "t_atm" to ("سحب من ATM" to "ATM withdrawal"), "t_out" to ("تحويل صادر" to "Transfer out"), "t_in" to ("تحويل وارد" to "Transfer in"),
    "t_online" to ("دفع أونلاين" to "Online payment"), "t_pos" to ("شراء بالكارت" to "Card purchase"), "t_bill" to ("سداد فاتورة" to "Bill payment"),
    "t_top" to ("شحن رصيد" to "Top-up"), "t_dep" to ("إيداع" to "Deposit"), "t_ref" to ("استرداد" to "Refund"), "t_other" to ("عملية" to "Transaction"),
    "p_atm" to ("مكان السحب" to "Location"), "p_out" to ("حوّلت إلى" to "Sent to"), "p_in" to ("استلمت من" to "Received from"),
    "p_online" to ("الموقع" to "Website"), "p_pos" to ("اشتريت من" to "Purchased at"), "p_bill" to ("الجهة" to "Biller"),
    "p_top" to ("الرقم" to "Number"), "p_dep" to ("الإيداع من" to "Deposited by"), "p_ref" to ("الجهة" to "Merchant"), "p_other" to ("الجهة" to "Party")
)
private val CATEN = mapOf("أكل" to "Food", "مواصلات" to "Transport", "فواتير" to "Bills", "تسوق" to "Shopping",
    "ألعاب" to "Games", "تحويلات" to "Transfers", "نقدي" to "Cash", "أخرى" to "Other", "دخل" to "Income")

@Composable fun s(k: String): String { val p = D[k] ?: return k; return if (LocalLang.current == "ar") p.first else p.second }
@Composable fun cn(c: String): String = if (LocalLang.current == "ar") c else CATEN[c] ?: c
@Composable fun cRed() = if (LocalDark.current) Color(0xFFE08A6C) else Color(0xFFB5543A)
@Composable fun cGreen() = if (LocalDark.current) Color(0xFF8FBF98) else Color(0xFF4C7A55)

class MainActivity : ComponentActivity() {
    private var ver by mutableIntStateOf(0)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        setContent { App(ver) { ver++ } }
    }
    override fun onResume() { super.onResume(); ver++ }
}

fun loadAvatar(c: Context): ImageBitmap? {
    val f = File(c.filesDir, "avatar.jpg")
    return if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
}

fun saveAvatar(c: Context, uri: Uri): ImageBitmap? = try {
    val bm = c.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })
    }
    if (bm == null) null else {
        val z = minOf(bm.width, bm.height)
        val sq = Bitmap.createBitmap(bm, (bm.width - z) / 2, (bm.height - z) / 2, z, z)
        val out = Bitmap.createScaledBitmap(sq, 400, 400, true)
        File(c.filesDir, "avatar.jpg").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        out.asImageBitmap()
    }
} catch (e: Exception) { null }

@Composable fun T(s: String, size: Int = 15, w: FontWeight = FontWeight.Normal, a: Float = 1f, c: Color = LocalInk.current) =
    Text(s, color = c.copy(alpha = a), fontSize = size.sp, fontWeight = w)

@Composable fun Modifier.glass(r: Dp = 24.dp): Modifier {
    val d = LocalDark.current
    val sh = RoundedCornerShape(r)
    val fill = if (d) listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))
               else listOf(Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0.45f))
    val edge = if (d) listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.2f))
               else listOf(Color.White, Color.Black.copy(alpha = 0.07f), Color.White.copy(alpha = 0.9f))
    return this.clip(sh).background(Brush.verticalGradient(fill)).border(1.dp, Brush.linearGradient(edge), sh)
}

fun fmt(v: Double) = String.format(Locale.US, "%,.0f", v)
fun fmt2(v: Double) = if (v % 1.0 == 0.0) fmt(v) else String.format(Locale.US, "%,.2f", v)

@Composable fun App(ver: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var lang by remember { mutableStateOf(sp.getString("lang", "ar") ?: "ar") }
    var dark by remember { mutableStateOf(sp.getBoolean("dark", false)) }
    var avatar by remember { mutableStateOf(loadAvatar(ctx)) }
    val all = remember(ver) { Store.load(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    val ink = if (dark) Color(0xFFEDE8E0) else Color(0xFF1F1D1A)
    CompositionLocalProvider(LocalInk provides ink, LocalDark provides dark, LocalLang provides lang,
        LocalLayoutDirection provides if (lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().background(if (dark) Color(0xFF141311) else Color(0xFFF9F8F6))) {
            Blobs(dark)
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Crossfade(tab, Modifier.weight(1f), label = "tab") { t ->
                    when (t) {
                        0 -> Home(all, avatar)
                        1 -> ListTab(all, refresh)
                        else -> Settings(refresh, lang, { lang = it; sp.edit().putString("lang", it).apply() },
                            dark, { dark = it; sp.edit().putBoolean("dark", it).apply() }, avatar, { avatar = it })
                    }
                }
                NavBar(tab) { tab = it }
            }
        }
    }
}

@Composable fun Blobs(dark: Boolean) {
    val t = rememberInfiniteTransition(label = "b")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Canvas(Modifier.fillMaxSize().blur(40.dp)) {
        val w = size.width; val h = size.height
        val al = if (dark) 0.35f else 0.4f
        drawCircle(Color(0xFF8FA58A).copy(alpha = al), w * 0.5f, Offset(w * (0.15f + 0.5f * a), h * 0.2f))
        drawCircle(Color(0xFFD9B98A).copy(alpha = al), w * 0.55f, Offset(w * (0.9f - 0.5f * a), h * 0.55f))
        drawCircle(Color(0xFFC77B5C).copy(alpha = al * 0.8f), w * 0.4f, Offset(w * (0.3f + 0.3f * a), h * (0.9f - 0.2f * a)))
    }
}

@Composable fun Appear(i: Int, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(i.coerceAtMost(8) * 40L); a.animateTo(1f, tween(400)) }
    Box(Modifier.graphicsLayer { alpha = a.value; translationY = (1 - a.value) * 40f }) { content() }
}

@Composable fun Pill(t: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(LocalInk.current.copy(alpha = if (sel) 0.14f else 0.05f), label = "pl")
    Box(Modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 7.dp)) { T(t, 13, if (sel) FontWeight.Bold else FontWeight.Normal) }
}

@Composable fun Avatar(b: ImageBitmap?, size: Dp) {
    if (b != null) Image(b, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    else Box(Modifier.size(size).glass(size / 2), contentAlignment = Alignment.Center) { T("م", 18, FontWeight.Bold) }
}

@Composable fun Home(all: List<Tx>, avatar: ImageBitmap?) {
    var whole by remember { mutableStateOf(false) }
    val now = Calendar.getInstance()
    val items = if (whole) all else all.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.time }
        c.get(Calendar.MONTH) == now.get(Calendar.MONTH) && c.get(Calendar.YEAR) == now.get(Calendar.YEAR)
    }
    val inc = items.filter { it.credit }.sumOf { it.amount }
    val exp = items.filter { !it.credit }.sumOf { it.amount }
    val net = inc - exp
    val shown by animateFloatAsState(net.toFloat(), tween(900), label = "n")
    val cats = items.filter { !it.credit }.groupBy { it.category }
        .map { it.key to it.value.sumOf { x -> x.amount } }.sortedByDescending { it.second }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Avatar(avatar, 44.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill(s("month"), !whole) { whole = false }; Pill(s("all"), whole) { whole = true }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().glass().padding(22.dp)) {
                T(s("net"), 14, a = 0.6f)
                Spacer(Modifier.height(6.dp))
                T(fmt(shown.toDouble()) + " " + s("egp"), 34, FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { T(s("inc"), 13, a = 0.6f); T("+" + fmt(inc), 17, FontWeight.Medium, c = cGreen()) }
                    Column { T(s("exp"), 13, a = 0.6f); T("-" + fmt(exp), 17, FontWeight.Medium, c = cRed()) }
                }
            }
        }
        if (items.isEmpty()) item { T(s("empty"), 14, a = 0.6f) }
        else if (cats.isNotEmpty()) item {
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                T(s("where"), 16, FontWeight.Medium)
                cats.forEach { (c, v) -> CatRow(cn(c), v, if (exp > 0) (v / exp).toFloat() else 0f) }
            }
        }
    }
}

@Composable fun CatRow(name: String, v: Double, frac: Float) {
    val f by animateFloatAsState(frac, tween(800, easing = FastOutSlowInEasing), label = "f")
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { T(name, 14); T(fmt(v), 14, a = 0.7f) }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(LocalInk.current.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(cRed()))
        }
    }
}

@Composable fun KV(k: String, v: String) {
    Column(Modifier.padding(top = 8.dp)) { T(k, 11, a = 0.5f); T(v, 13) }
}

@Composable fun ListTab(all: List<Tx>, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    var open by remember { mutableStateOf<String?>(null) }
    val loc = remember(lang) { Locale.forLanguageTag("$lang-u-nu-latn") }
    val short = remember(lang) { SimpleDateFormat("d/M  HH:mm", loc) }
    val long = remember(lang) { SimpleDateFormat("EEEE d MMMM yyyy  ·  HH:mm", loc) }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        itemsIndexed(all, key = { _, t -> t.id }) { i, t ->
            Appear(i) {
                Column(Modifier.fillMaxWidth().glass(20.dp).clickable { open = if (open == t.id) null else t.id }
                    .animateContentSize(spring(dampingRatio = 0.8f)).padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            T(t.merchant, 15, FontWeight.Medium)
                            T(s("t_" + t.type) + "  ·  " + cn(t.category) + "  ·  " + short.format(Date(t.time)), 12, a = 0.55f)
                        }
                        T((if (t.credit) "+" else "-") + fmt2(t.amount), 16, FontWeight.Bold, c = if (t.credit) cGreen() else cRed())
                    }
                    if (open == t.id) {
                        Spacer(Modifier.height(6.dp))
                        KV(s("type"), s("t_" + t.type))
                        KV(s("p_" + t.type), t.merchant)
                        if (t.card.isNotEmpty()) KV(s("card"), "•••• " + t.card)
                        if (t.fee > 0) KV(s("fee"), fmt2(t.fee) + " " + s("egp"))
                        if (t.balance >= 0) KV(s("bal"), fmt2(t.balance) + " " + s("egp"))
                        if (t.ref.isNotEmpty()) KV(s("ref"), t.ref)
                        KV(s("msg"), t.body.ifBlank { t.merchant })
                        KV(s("src"), t.src)
                        KV(s("when"), long.format(Date(t.time)))
                        KV(s("cat"), cn(t.category))
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Cat.all.forEach { c -> Pill(cn(c), c == t.category) { Store.setCategory(ctx, t.id, c); refresh() } }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun GSwitch(on: Boolean, set: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 22.dp else 0.dp, spring(dampingRatio = 0.7f), label = "sw")
    val bg by animateColorAsState(if (on) cGreen() else LocalInk.current.copy(alpha = 0.2f), label = "sb")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.width(50.dp).height(28.dp).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable { set(!on) }.padding(3.dp)) {
            Box(Modifier.offset(x = x).size(22.dp).clip(CircleShape).background(Color.White))
        }
    }
}

@Composable fun Settings(refresh: () -> Unit, lang: String, onLang: (String) -> Unit, dark: Boolean,
                         onDark: (Boolean) -> Unit, avatar: ImageBitmap?, onAvatar: (ImageBitmap) -> Unit) {
    val ctx = LocalContext.current
    val added = s("added")
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) saveAvatar(ctx, u)?.let(onAvatar)
    }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { T(s("set"), 22, FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth().glass(20.dp).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                T(s("lang"), 16, FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("العربية", lang == "ar") { onLang("ar") }; Pill("English", lang == "en") { onLang("en") }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().glass(20.dp).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(avatar, 40.dp); T(s("photo"), 16, FontWeight.Medium)
                }
                Pill(s("pick"), false) { pick.launch("image/*") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().glass(20.dp).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                T(s("night"), 16, FontWeight.Medium); GSwitch(dark, onDark)
            }
        }
        item { Spacer(Modifier.height(4.dp)); T(s("setup"), 14, a = 0.6f) }
        item { GBtn(s("p1")) { perm.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)) } }
        item { GBtn(s("p2")) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
        item {
            GBtn(s("p3")) {
                val n = Store.importInbox(ctx)
                Toast.makeText(ctx, "$added $n", Toast.LENGTH_SHORT).show(); refresh()
            }
        }
    }
}

@Composable fun GBtn(label: String, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val p by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (p) 0.96f else 1f, spring(dampingRatio = 0.5f), label = "p")
    Box(Modifier.fillMaxWidth().scale(sc).glass(20.dp)
        .clickable(interactionSource = src, indication = null, onClick = onClick).padding(18.dp)) { T(label, 16, FontWeight.Medium) }
}

@Composable fun NavBar(tab: Int, set: (Int) -> Unit) {
    val labels = listOf(s("home"), s("tx"), s("set"))
    Row(Modifier.navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)
        .fillMaxWidth().glass(30.dp).padding(6.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = tab == i
            val bg by animateColorAsState(if (sel) LocalInk.current.copy(alpha = 0.12f) else Color.Transparent, label = "n")
            val sc by animateFloatAsState(if (sel) 1f else 0.94f, spring(dampingRatio = 0.6f), label = "sc")
            Box(Modifier.weight(1f).scale(sc).clip(RoundedCornerShape(24.dp)).background(bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { set(i) }
                .padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                T(l, 14, if (sel) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
