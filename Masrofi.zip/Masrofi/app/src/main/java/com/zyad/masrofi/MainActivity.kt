package com.zyad.masrofi

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

val LocalInk = compositionLocalOf { Color.Black }
val LocalDark = compositionLocalOf { false }

class MainActivity : ComponentActivity() {
    private var ver by mutableIntStateOf(0)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App(ver) { ver++ } }
        }
    }
    override fun onResume() { super.onResume(); ver++ }
}

@Composable fun T(s: String, size: Int = 15, w: FontWeight = FontWeight.Normal, a: Float = 1f, c: Color = LocalInk.current) =
    Text(s, color = c.copy(alpha = a), fontSize = size.sp, fontWeight = w)

@Composable fun Modifier.glass(r: Dp = 24.dp): Modifier {
    val d = LocalDark.current
    val sh = RoundedCornerShape(r)
    return this.clip(sh)
        .background(Brush.verticalGradient(listOf(
            Color.White.copy(alpha = if (d) 0.10f else 0.5f), Color.White.copy(alpha = if (d) 0.04f else 0.2f))))
        .border(1.dp, Brush.linearGradient(listOf(
            Color.White.copy(alpha = if (d) 0.35f else 0.9f), Color.White.copy(alpha = 0.05f),
            Color.White.copy(alpha = if (d) 0.2f else 0.6f))), sh)
}

fun fmt(v: Double) = String.format(Locale.US, "%,.0f", v)

@Composable fun App(ver: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val all = remember(ver) { Store.load(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    val ink = if (dark) Color(0xFFEDE8E0) else Color(0xFF1F1D1A)
    CompositionLocalProvider(LocalInk provides ink, LocalDark provides dark) {
        Box(Modifier.fillMaxSize().background(if (dark) Color(0xFF161513) else Color(0xFFEFEBE4))) {
            Blobs(dark)
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Crossfade(tab, Modifier.weight(1f), label = "tab") { t ->
                    when (t) { 0 -> Home(all); 1 -> ListTab(all, refresh); else -> Settings(refresh) }
                }
                NavBar(tab) { tab = it }
            }
        }
    }
}

@Composable fun Blobs(dark: Boolean) {
    val t = rememberInfiniteTransition(label = "b")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Canvas(Modifier.fillMaxSize().blur(40.dp)) {
        val w = size.width; val h = size.height
        val al = if (dark) 0.35f else 0.6f
        drawCircle(Color(0xFF8FA58A).copy(alpha = al), w * 0.5f, Offset(w * (0.15f + 0.5f * a), h * 0.2f))
        drawCircle(Color(0xFFD9B98A).copy(alpha = al), w * 0.55f, Offset(w * (0.9f - 0.5f * a), h * 0.55f))
        drawCircle(Color(0xFFC77B5C).copy(alpha = al * 0.8f), w * 0.4f, Offset(w * (0.3f + 0.3f * a), h * (0.9f - 0.2f * a)))
    }
}

@Composable fun Appear(i: Int, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(i.coerceAtMost(8) * 40L); a.animateTo(1f, tween(400)) }
    Box(Modifier.graphicsLayer { alpha = a.value; translationY = (1 - a.value) * 40f }) { content() }
}

@Composable fun Home(all: List<Tx>) {
    val now = Calendar.getInstance()
    val month = all.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.time }
        c.get(Calendar.MONTH) == now.get(Calendar.MONTH) && c.get(Calendar.YEAR) == now.get(Calendar.YEAR)
    }
    val spent = month.filter { !it.credit }.sumOf { it.amount }
    val got = month.filter { it.credit }.sumOf { it.amount }
    val shown by animateFloatAsState(spent.toFloat(), tween(900), label = "s")
    val cats = month.filter { !it.credit }.groupBy { it.category }
        .map { it.key to it.value.sumOf { x -> x.amount } }.sortedByDescending { it.second }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().glass().padding(22.dp)) {
                T("صرفت الشهر ده", 14, a = 0.6f)
                Spacer(Modifier.height(6.dp))
                T(fmt(shown.toDouble()) + " جنيه", 34, FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                T("دخل: " + fmt(got) + " جنيه", 15, a = 0.7f)
            }
        }
        if (month.isEmpty()) item {
            T("مفيش عمليات لسه. من الإعدادات فعّل الصلاحيات واستورد الرسائل.", 14, a = 0.6f)
        } else item {
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                T("صرفت فين", 16, FontWeight.Medium)
                cats.forEach { (c, v) -> CatRow(c, v, if (spent > 0) (v / spent).toFloat() else 0f) }
            }
        }
    }
}

@Composable fun CatRow(name: String, v: Double, frac: Float) {
    val f by animateFloatAsState(frac, tween(800, easing = FastOutSlowInEasing), label = "f")
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T(name, 14); T(fmt(v), 14, a = 0.7f)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(LocalInk.current.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                .background(if (LocalDark.current) Color(0xFFE08A6C) else Color(0xFFB5543A)))
        }
    }
}

@Composable fun ListTab(all: List<Tx>, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val dark = LocalDark.current
    var open by remember { mutableStateOf<String?>(null) }
    val red = if (dark) Color(0xFFE08A6C) else Color(0xFFB5543A)
    val green = if (dark) Color(0xFF8FBF98) else Color(0xFF4C7A55)
    val df = remember { SimpleDateFormat("d/M  HH:mm", Locale.US) }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        itemsIndexed(all, key = { _, t -> t.id }) { i, t ->
            Appear(i) {
                Column(Modifier.fillMaxWidth().glass(20.dp)
                    .clickable { open = if (open == t.id) null else t.id }
                    .animateContentSize(spring(dampingRatio = 0.8f)).padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            T(t.merchant, 15, FontWeight.Medium)
                            T(t.category + "  ·  " + df.format(Date(t.time)), 12, a = 0.55f)
                        }
                        T((if (t.credit) "+" else "-") + fmt(t.amount), 16, FontWeight.Bold, c = if (t.credit) green else red)
                    }
                    if (open == t.id) {
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Cat.all.forEach { c ->
                                val sel = c == t.category
                                Box(Modifier.clip(RoundedCornerShape(14.dp))
                                    .background(LocalInk.current.copy(alpha = if (sel) 0.18f else 0.06f))
                                    .clickable { Store.setCategory(ctx, t.id, c); refresh() }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)) { T(c, 13) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun Settings(refresh: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        T("الإعدادات", 22, FontWeight.Bold)
        GBtn("١. السماح بقراءة الرسائل") { launcher.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)) }
        GBtn("٢. السماح بقراءة إشعارات تطبيقات البنوك") {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        GBtn("٣. استيراد الرسائل القديمة") {
            val n = Store.importInbox(ctx)
            Toast.makeText(ctx, "اتضاف $n عملية", Toast.LENGTH_SHORT).show()
            refresh()
        }
    }
}

@Composable fun GBtn(label: String, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val p by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (p) 0.96f else 1f, spring(dampingRatio = 0.5f), label = "p")
    Box(Modifier.fillMaxWidth().scale(s).glass(20.dp)
        .clickable(interactionSource = src, indication = null, onClick = onClick).padding(18.dp)) {
        T(label, 16, FontWeight.Medium)
    }
}

@Composable fun NavBar(tab: Int, set: (Int) -> Unit) {
    val labels = listOf("الرئيسية", "العمليات", "الإعدادات")
    Row(Modifier.navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)
        .fillMaxWidth().glass(30.dp).padding(6.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = tab == i
            val bg by animateColorAsState(if (sel) LocalInk.current.copy(alpha = 0.12f) else Color.Transparent, label = "n")
            val sc by animateFloatAsState(if (sel) 1f else 0.94f, spring(dampingRatio = 0.6f), label = "sc")
            Box(Modifier.weight(1f).scale(sc).clip(RoundedCornerShape(24.dp)).background(bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { set(i) }
                .padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                T(l, 14, if (sel) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
